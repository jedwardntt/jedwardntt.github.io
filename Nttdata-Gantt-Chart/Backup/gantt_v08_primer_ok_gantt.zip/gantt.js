//=============================================================
// Start: SAP Analytics Cloud - Custom Windget - NTT Data Gantt
(function() { 
	let _shadowRoot;
	
	let template = document.createElement("template");
	template.innerHTML = `
		<style>
		:host {
			border-radius: 25px;
			border-width: 4px;
			border-color: black;
			border-style: solid;
			display: block;
		} 
		</style> 
		<div id="chart_div">X</div>
	`;
	
	

	class Gantt extends HTMLElement {
		constructor() {
			console.log("=======> Debug - Constructor");
			super(); 
			let _shadowRoot = this.attachShadow({mode: "open"});
			_shadowRoot.appendChild(template.content.cloneNode(true));
			
			this.addEventListener("click", event => {
				var event = new Event("onClick");
				this.dispatchEvent(event);
			});
			this._props = {};

			//=============================================================
			// Start: Google Chart Code specific for Gantt
			console.log("=======> Debug - Google Chart - Start load library");
			//========================================================================================================
			//========================================================================================================
			//========================================================================================================
			
			
			//========================================================================================================
			//========================================================================================================
			//========================================================================================================
/*
			console.log("=======> Debug - Google Chart - Start init Gantt chart - step 1");

			console.log("=======> Debug - Google Chart - Start init Gantt chart - step 2");
			
			console.log("=======> Debug - Google Chart - Start init Gantt chart - step 3");
			
			console.log("=======> Debug - Google Chart - Start init Gantt chart - step 4");
*/			
		}

		onCustomWidgetBeforeUpdate(changedProperties) {
			console.log("=======> Debug - onCustomWidgetBeforeUpdate");
			
			this._props = { ...this._props, ...changedProperties };
		}

		onCustomWidgetAfterUpdate(changedProperties) {
			console.log("=======> Debug - onCustomWidgetAfterUpdate");
			
			if ("color" in changedProperties) {
				this.style["background-color"] = changedProperties["color"];
			}
			if ("opacity" in changedProperties) {
				this.style["opacity"] = changedProperties["opacity"];
			}
		}
	}

	customElements.define("com-nttdata-ses-cw-gantt", Gantt);
	
	// UTILS

	
})();